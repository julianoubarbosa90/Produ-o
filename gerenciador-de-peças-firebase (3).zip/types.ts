
export interface Part {
  id: string;
  name: string;
  quantity: number;
}