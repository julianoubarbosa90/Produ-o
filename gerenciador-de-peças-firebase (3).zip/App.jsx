import React, { useState, useEffect, useCallback, createElement } from 'react';
import htm from 'htm';
import { db } from './services/firebase.js';
import { collection, addDoc, onSnapshot, doc, deleteDoc, query, orderBy } from 'firebase/firestore';
import Header from './components/Header.jsx';
import PartForm from './components/PartForm.jsx';
import PartList from './components/PartList.jsx';
import Spinner from './components/Spinner.jsx';
import Alert from './components/Alert.jsx';

const html = htm.bind(createElement);

const App = () => {
  const [parts, setParts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const q = query(collection(db, 'pecas'), orderBy('name', 'asc'));
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const partsData = [];
      querySnapshot.forEach((doc) => {
        partsData.push({ id: doc.id, ...doc.data() });
      });
      setParts(partsData);
      setLoading(false);
    }, (err) => {
      console.error("Error fetching parts: ", err);
      setError("Não foi possível carregar as peças. Verifique sua conexão e as configurações do Firebase.");
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAddPart = useCallback(async (name, quantity) => {
    if (name.trim() === '' || quantity <= 0) {
      setError("Por favor, insira um nome válido e uma quantidade positiva.");
      return;
    }
    setError(null);
    try {
      await addDoc(collection(db, 'pecas'), { name, quantity });
    } catch (err) {
      console.error("Error adding part: ", err);
      setError("Ocorreu um erro ao adicionar a peça.");
    }
  }, []);

  const handleDeletePart = useCallback(async (id) => {
    try {
      await deleteDoc(doc(db, 'pecas', id));
    } catch (err) {
      console.error("Error deleting part: ", err);
      setError("Ocorreu um erro ao remover a peça.");
    }
  }, []);

  return html`
    <div className="min-h-screen bg-gray-100 text-gray-800 font-sans">
      <${Header} />
      <main className="container mx-auto p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          ${error && html`<${Alert} message=${error} onClose=${() => setError(null)} />`}
          
          <div className="bg-white rounded-lg shadow-lg p-6 md:p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">Cadastrar Nova Peça</h2>
            <${PartForm} onSubmit=${handleAddPart} />
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6 md:p-8">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">Inventário de Peças</h2>
            ${loading ? html`
              <div className="flex justify-center items-center h-40">
                <${Spinner} />
              </div>
            ` : html`
              <${PartList} parts=${parts} onDelete=${handleDeletePart} />
            `}
          </div>
        </div>
      </main>
      <footer className="text-center p-4 text-gray-500 text-sm">
        <p>&copy; ${new Date().getFullYear()} Gerenciador de Peças. Todos os direitos reservados.</p>
      </footer>
    </div>
  `;
};

export default App;