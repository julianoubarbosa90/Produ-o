import React, { useState, createElement } from 'react';
import htm from 'htm';

const html = htm.bind(createElement);

const PartForm = ({ onSubmit }) => {
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    await onSubmit(name, parseInt(quantity, 10));
    setName('');
    setQuantity('');
    setSubmitting(false);
  };

  return html`
    <form onSubmit=${handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
      <div className="md:col-span-1">
        <label htmlFor="part-name" className="block text-sm font-medium text-gray-600 mb-1">
          Nome da Peça
        </label>
        <input
          id="part-name"
          type="text"
          value=${name}
          onChange=${(e) => setName(e.target.value)}
          placeholder="Ex: Parafuso Sextavado"
          required
          className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-light focus:border-brand-light transition duration-150"
        />
      </div>
      <div>
        <label htmlFor="part-quantity" className="block text-sm font-medium text-gray-600 mb-1">
          Quantidade
        </label>
        <input
          id="part-quantity"
          type="number"
          value=${quantity}
          onChange=${(e) => setQuantity(e.target.value)}
          placeholder="Ex: 100"
          required
          min="1"
          className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-light focus:border-brand-light transition duration-150"
        />
      </div>
      <button
        type="submit"
        disabled=${submitting || !name || !quantity}
        className="w-full px-4 py-2 bg-brand-secondary text-white font-semibold rounded-md shadow-sm hover:bg-brand-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-dark transition duration-200 ease-in-out disabled:bg-gray-400 disabled:cursor-not-allowed"
      >
        ${submitting ? 'Adicionando...' : 'Adicionar Peça'}
      </button>
    </form>
  `;
};

export default PartForm;