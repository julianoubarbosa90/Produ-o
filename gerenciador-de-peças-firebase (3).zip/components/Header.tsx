
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-brand-primary shadow-md">
      <div className="container mx-auto px-4 py-5 md:px-8">
        <h1 className="text-3xl font-bold text-white tracking-wide">
          Gerenciador de Peças
        </h1>
        <p className="text-blue-200 mt-1">Seu inventário centralizado com Firebase</p>
      </div>
    </header>
  );
};

export default Header;