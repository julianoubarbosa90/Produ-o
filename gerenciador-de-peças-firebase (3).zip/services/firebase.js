import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration provided by the user.
// In a real production app, these should be stored in environment variables.
const firebaseConfig = {
  apiKey: "AIzaSyDYm7yx16yxkzw2q9ywAMgptP4pRlFp3qY",
  authDomain: "calculadora-d4809.firebaseapp.com",
  projectId: "calculadora-d4809",
  storageBucket: "calculadora-d4809.appspot.com",
  messagingSenderId: "523735280269",
  appId: "1:523735280269:web:ba196d97667547668fd0c4",
  measurementId: "G-E62MVL7JYQ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export { db };